const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();

app.use(cors());

const server = http.createServer(app);

const rooms = {};

function generateRoomCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

const io = new Server(server, {
    cors: { origin: "*" }
});

io.on("connection", (socket) => {
    console.log("Usuário conectado:", socket.id);

    
    socket.on("disconnect", () => {

    console.log("Usuário desconectado:", socket.id);

    for (const roomCode in rooms){

        const room = rooms[roomCode];

        const playerIndex = room.players.findIndex(
            player => player.socketId === socket.id
        );

        if (playerIndex !== -1){

            room.players.splice(playerIndex, 1);

            console.log("Player removido da sala:", roomCode);

            io.to(roomCode).emit("player-left", {
                message: "Jogador saiu da sala"
            });

            if (room.players.length === 0){
                delete rooms[roomCode];

                console.log("Sala removida:", roomCode);
            }

            break;
        }

    }

});







    socket.on("create-room", (data) => {
        const { username } = data;
        const roomCode = generateRoomCode();
        rooms[roomCode] = {
            players: [
                {
                    socketId: socket.id,
                    username
                }
            ]
        };
        socket.join(roomCode);
        console.log("Sala criada:", roomCode);
        socket.emit("room-created", {roomCode});
    });


    socket.on("join-room", (data) => {
        const { roomCode, username } = data;
        const room = rooms[roomCode];
        if (!room) {
            socket.emit("room-not-found", {message: "Sala não encontrada"});
            return;
        }

        if (room.players.length >= 2) {
            socket.emit("room-full", {message: "Sala cheia"});
            return;
        }

        socket.join(roomCode);
        room.players.push({
            socketId: socket.id,
            username
        });
        console.log("Player entrou na sala:", roomCode);
        io.to(roomCode).emit("player-joined", {
            players: room.players
        });

    });

});

server.listen(3334, () => {
    console.log("Duel Server rodando na porta 3334");
});